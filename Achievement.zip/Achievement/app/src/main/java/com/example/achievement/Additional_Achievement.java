package com.example.achievement;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Additional_Achievement extends AppCompatActivity {
    //get Achievement data from web server

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.additional);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        int option = bundle.getInt("option");

        //Spinner에 눌린 업적에 따라 label 변경
        switch (option){
            case 0:
                setTitle("달성 업적");
                break;

            case 1:
                setTitle("미달성_업적");
                break;

            case 2:
                setTitle("시작 가능한 업적");
                break;

            case 3:
                setTitle("진행중인 업적");
                break;

            default:
                setTitle("업적");
                break;
        }


        //Todo: scrollView에 업적 넣어주기







        // Button이 눌리는 경우 돌아가기
        Button back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("option", option);
                finish();
            }


        });




    }



}
